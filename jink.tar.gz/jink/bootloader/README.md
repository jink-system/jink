# Bootloader directory

In this directory there are all the bootloader available for jink.
If you want to add more bootloader, just add the config here and edit .iso.sh file.
