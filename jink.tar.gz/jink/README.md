# Jink Operating System

Version : 0.0.1

TODO:
	C Standard Library
	Jink Kernel Library
	SYSLINUX Implementation
