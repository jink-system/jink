#ifndef STDDEF_H
#define STDDEF_H

typedef unsigned int size_t; 
typedef int ptrdiff_t;
typedef long long max_align_t;

#endif
