#ifndef STRING_H
#define STRING_H

#include <stddef.h>

int memcmp(const void*, const void*, size_t);

#endif
