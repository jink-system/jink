# make iso with grub

grub-mkrescue ./iso/ -o jink.iso
